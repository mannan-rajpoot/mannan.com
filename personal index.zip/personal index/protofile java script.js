var Typed= new Typed(".text",{
    strings:["Tiktoker" , "Youtuber  " , "Web Developer"],
    typeSpeed:100,
    backSpeed:100,
    backDelay:1000,
    loop:true
});
